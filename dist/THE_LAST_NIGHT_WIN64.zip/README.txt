THE LAST NIGHT
==============

Windows 64-bit build (portable, no installation required).

HOW TO RUN
  Keep the "assets" folder next to THE_LAST_NIGHT.exe, then run the exe.
  The game writes the_last_night.log next to itself.

CONTROLS
  WASD move - mouse look - LMB attack/fire - RMB aim - Shift sprint
  Space jump - R reload - 1..8 or wheel switch weapon - F flashlight
  H medkit - E interact/build/repair/buy - Tab inventory - Esc pause

NOTES
  * Built from source with Zig 0.17 / mingw-w64. This executable was
    cross-compiled and verified as a Windows GUI PE (icon + version resource),
    but it could not be executed in the build environment - no Windows host or
    emulator was available. Please report anything that misbehaves.
  * The same sources build and run on Linux (headless harness); see
    docs/TESTING.md in the source archive for the actual test results.
  * All art, audio and code in this game were generated/created for this
    project. Font atlases are rasterised from the DejaVu fonts; the licence
    text is included in assets/fonts/LICENSE_DejaVu.txt.
