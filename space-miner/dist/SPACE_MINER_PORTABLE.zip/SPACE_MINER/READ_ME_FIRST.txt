SPACE MINER — portable build
============================

1. Unzip this whole folder anywhere you like.
2. Run SPACE_MINER.exe

SPACE_MINER.exe starts a private local web server on 127.0.0.1 and opens
the game in a chromeless Microsoft Edge / Google Chrome app window.
No internet connection is used; nothing leaves your machine.

If no Chromium-based browser is present, the game opens in your default
browser instead, or you can open game\index.html directly.

Your pilot profile is saved automatically by the game.
